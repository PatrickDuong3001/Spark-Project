Included Files:
1) Source Code
2) Documentation
3) Ppt
4) Demo Video, visit the youtube link -  https://youtu.be/hcVFeYguPMQ
